import React from 'react';
import {NativeStackScreenProps} from '@react-navigation/native-stack';
import {createMaterialTopTabNavigator} from '@react-navigation/material-top-tabs';
import RequestNavigator from './Request/RequestNavigator';
//import ApprovalNavigator from './Approval/ApprovalNavigator';
import {useTranslation} from 'react-i18next';

type RootStackParamList = {
  RequestList: undefined;
  ApprovalList: undefined;
};

const Tab = createMaterialTopTabNavigator<RootStackParamList>();

const WorkOrderNavigator = () => {
  const {t} = useTranslation();
  return (
    <Tab.Navigator
      screenOptions={{
        swipeEnabled: false,
        tabBarLabelStyle: {fontSize: 12},
        tabBarStyle: {backgroundColor: '#fff', borderEndColor: '#000'},
      }}>
      <Tab.Screen
        name="RequestList"
        component={RequestNavigator}
        options={{
          title: t('navigate:request'),
        }}
      />
      
    </Tab.Navigator>
  );
};

export type LeaveNavigatorProp = NativeStackScreenProps<
  RootStackParamList,
  'RequestList'
>;

export default WorkOrderNavigator;

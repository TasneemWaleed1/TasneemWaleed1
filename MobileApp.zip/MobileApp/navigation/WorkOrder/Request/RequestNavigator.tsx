import React from 'react';
import {
  createNativeStackNavigator,
  NativeStackScreenProps,
} from '@react-navigation/native-stack';
import {useTranslation} from 'react-i18next';
import RequestScreen from '../../../screens/WorkOrder/Request/RequestScreen';
import RequestDetailScreen from '../../../screens/WorkOrder/Request/RequestDetailScreen';


type RootStackParamList = {
  RequestScreen: undefined;
  RequestDetailScreen: {};
  RequestAddScreen: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();

const RequestNavigator = () => {
  const {t} = useTranslation();

  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: {
          backgroundColor: '#22679B',
        },
        headerTintColor: '#fff',
        headerTitleStyle: {
          fontWeight: 'bold',
        },
      }}>
      <Stack.Screen
        name="RequestScreen"
        component={RequestScreen}
        options={{title: t('navigate:requestList')}}
      />
      <Stack.Screen
        name="RequestDetailScreen"
        component={RequestDetailScreen}
        options={{title: t('navigate:details')}}
      />
      
    </Stack.Navigator>
  );
};

export type RequestNavigationProp = NativeStackScreenProps<
  RootStackParamList,
  'RequestScreen'
>;

export default RequestNavigator;

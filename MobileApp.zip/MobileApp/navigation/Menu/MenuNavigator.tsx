import React from 'react';
import {
  createNativeStackNavigator,
  NativeStackScreenProps,
} from '@react-navigation/native-stack';
import MenuScreen from '../../screens/Menu/MenuScreen';
import {useTranslation} from 'react-i18next';

type RootStackParamList = {
  MenuScreen: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();

const MenuNavigator = () => {
  const {t} = useTranslation();

  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: {
          backgroundColor: '#22679B',
        },
        headerTintColor: '#fff',
        headerTitleStyle: {
          fontWeight: 'bold',
        },
      }}>
      <Stack.Screen
        name="MenuScreen"
        component={MenuScreen}
        options={{title: t('navigate:menu')}}
      />
    </Stack.Navigator>
  );
};

export type MenuScreenNavigationProp = NativeStackScreenProps<
  RootStackParamList,
  'MenuScreen'
>;

export default MenuNavigator;

import React from 'react';
import {
  createNativeStackNavigator,
  NativeStackScreenProps,
} from '@react-navigation/native-stack';
import {useTranslation} from 'react-i18next';
import HomeScreen from '../../screens/Home/HomeScreen';
import TransferNavigator from '../Transfer/TransferNavigator';
import DisposalNavigator from '../Disposal/DisposalNavigator';
import BOMNavigator from '../BOM/BOMNavigator';
import RoutingNavigator from '../Routing/RoutingNavigator';
import WorkOrderNavigator from '../WorkOrder/WorkOrderNavigator';

type RootStackParamList = {
  HomeScreen: undefined;
  TransferNavigator: undefined;
  DisposalNavigator: undefined;
  BOMNavigator: undefined;
  RoutingNavigator: undefined;
  WorkOrderNavigator: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();

const HomeNavigator = () => {
  const {t} = useTranslation();

  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: {
          backgroundColor: '#22679B',
        },
        headerTintColor: '#fff',
        headerTitleStyle: {
          fontWeight: 'bold',
        },
      }}>
      <Stack.Screen
        name="HomeScreen"
        component={HomeScreen}
        options={{title: t('navigate:home')}}
      />
      <Stack.Screen
        name="TransferNavigator"
        component={TransferNavigator}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="DisposalNavigator"
        component={DisposalNavigator}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="BOMNavigator"
        component={BOMNavigator}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="RoutingNavigator"
        component={RoutingNavigator}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="WorkOrderNavigator"
        component={WorkOrderNavigator}
        options={{headerShown: false}}
      />
    </Stack.Navigator>
  );
};

export type HomeScreenNavigationProp = NativeStackScreenProps<
  RootStackParamList,
  'TransferNavigator'
>;

export default HomeNavigator;

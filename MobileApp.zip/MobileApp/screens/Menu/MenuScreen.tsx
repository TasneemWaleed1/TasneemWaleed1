import React from 'react';
import {StyleSheet, View, I18nManager} from 'react-native';
import RNRestart from 'react-native-restart';
import {ListItem, Icon} from '@rneui/base';
import Chevron from '../../components/Chevron';
import {useSelector, useDispatch} from 'react-redux';
import {userInfo, signOutAsync} from '../../features/authentication/authSlice';
import {useTranslation} from 'react-i18next';

const MenuScreen = () => {
  const {t, i18n} = useTranslation();
  const selectedLanguageCode = i18n.language;

  const state = useSelector(userInfo);
  const dispatch = useDispatch();

  const setLanguage = (code: any) => {
    if (i18n.language === 'العربية') {
      code = 'English';
    } else {
      code = 'العربية';
    }
    return i18n
      .changeLanguage(code)
      .then(() => I18nManager.forceRTL(i18n.language === 'العربية'))
      .then(() => RNRestart.Restart());
  };

  return (
    <View style={styles.container}>
      {/* <ListItem bottomDivider>
        <ListItem.Content>
          <ListItem.Title>{t('common:language')}</ListItem.Title>
        </ListItem.Content>
        <ListItem.ButtonGroup
          buttons={[i18n.language === 'English' ? 'العربية' : 'English']}
          onPress={() => setLanguage(selectedLanguageCode)}
        />
      </ListItem> */}
      <ListItem
        onPress={() => dispatch(signOutAsync(state.userInfo!))}
        bottomDivider>
        <Icon name="logout" size={20} />
        <ListItem.Content>
          <ListItem.Title>{t('navigate:signOut')}</ListItem.Title>
        </ListItem.Content>
        <Chevron i18n={i18n} />
      </ListItem>
    </View>
  );
};

export default MenuScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});

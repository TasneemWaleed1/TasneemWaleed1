import React, {useState, useEffect} from 'react';
import {
  StyleSheet,
  View,
  FlatList,
  TouchableOpacity,
  GestureResponderEvent,
  ActivityIndicator,
} from 'react-native';
import {Button, Text, Icon} from '@rneui/base';
import APIKit from '../../../helpers/ApiKit';
import {RequestNavigationProp} from '../../../navigation/BOM/Request/RequestNavigator';

interface itemObject {
  Item_Number?: string;
  Address_Number?: string;
  Branch?: string;
  Requested_No: number;
  Typ_BOM?: string;
  UM?: string;
  Effective_From?: string;
  Status?: string;
  Description?: string;
}

type Props = {
  request: itemObject;
  onPress: (event: GestureResponderEvent) => void;
};

const Item = ({request, onPress}: Props) => (
  <TouchableOpacity onPress={onPress}>
    <View style={styles.requestContainer}>
      <View style={styles.request_detail}>
      <Text>Request Number</Text>
        <Text>Item Number</Text>
        <Text>Branch</Text>
        <Text>Type BOM</Text>
       
        <Text>From Date</Text>
        <Text>Status</Text>
        <Text>Description</Text>
      </View>
      <View style={styles.request_detail}>
        <Text>{request.Requested_No}</Text>
        <View style={styles.request_header}>
          <Text>{request.Item_Number}</Text>
        </View>
        <Text>{request.Branch}</Text>
        <Text>{request.Typ_BOM}</Text>
      
        <Text>{request.Effective_From}</Text>
        <Text style={styles.request_status}>{request.Status}</Text>
        <View style={styles.request_header}>
        <Text style={styles.request_status}>{request.Description}</Text>
        </View>
      </View>
    </View>
  </TouchableOpacity>
);

const RequestScreen = ({navigation}: RequestNavigationProp) => {
  const [data, setData] = useState([]);
  const [isFetching, setIsFetching] = useState(false);

  useEffect(() => {
    RequestList();
  }, [navigation]);

  const RequestList = async () => {
    try {
      setIsFetching(true);
      let response = await APIKit.post(
        '/jderest/v3/orchestrator/BOM_Requests',
        {},
      );

      const rowset = response.data.BOM_Requests_1.rowset;

      let sortedData = rowset.sort((a: itemObject, b: itemObject) =>
        a.Requested_No < b.Requested_No ? 1 : -1,
      );

      setIsFetching(false);
      setData(sortedData);
    } catch (error) {
      console.log(error);
      setIsFetching(false);
    }
  };

  const onRefresh = () => {
    setIsFetching(true);
    RequestList();
  };

  const pressHandle = (item: itemObject) => {
    navigation.navigate('RequestDetailScreen', item);
  };

  const renderItem = ({item}: {item: itemObject}) => {
    return <Item onPress={() => pressHandle(item)} request={item} />;
  };

  if (isFetching) {
    return (
      <View style={styles.centerContainer}>
        <ActivityIndicator size="large" color="#000" />
      </View>
    );
  }

  if (data === undefined || data.length === 0) {
    return (
      <View style={styles.centerContainer}>
        <Text style={styles.centerText}>No Requests</Text>
        <Icon
          name="reload"
          type="ionicon"
          size={25}
          color="#aaa9ad"
          style={styles.reloadIcon}
          onPress={onRefresh}
        />
        
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.container}>
        <FlatList
          data={data}
          renderItem={renderItem}
          keyExtractor={item => item.Requested_No.toString()}
          onRefresh={() => onRefresh()}
          refreshing={isFetching}
        />
      </View>
      
    </View>
  );
};

export default RequestScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  centerText: {
    color: '#aaa9ad',
    fontWeight: 'bold',
    fontSize: 20,
  },
  reloadIcon: {
    padding: 10,
  },
  requestContainer: {
    backgroundColor: 'white',
    flexDirection: 'row',
    flex: 1,
    borderBottomWidth: 1,
    borderBottomColor: 'gray',
    paddingLeft: 10,
    paddingRight: 15,
    paddingTop: 15,
    paddingBottom: 15,
  },
  request_detail: {
    marginLeft: 10,
    flexDirection: 'column',
    flex: 1,
  },
  request_header: {
    alignItems: 'center',
    justifyContent: 'space-between',
    flexDirection: 'row',
    width: 300,
  },
  request_status: {
    fontWeight: 'bold',
  },
});

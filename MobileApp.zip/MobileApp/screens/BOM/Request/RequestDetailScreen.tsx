import React, {useState, useEffect} from 'react';
import {
  StyleSheet,
  View,
  FlatList,
  Alert,
  TouchableOpacity,
  GestureResponderEvent,
  ActivityIndicator,
} from 'react-native';
import {Text, Icon} from '@rneui/base';
import APIKit from '../../../helpers/ApiKit';
import {RequestNavigationProp} from '../../../navigation/BOM/Request/RequestNavigator';

interface itemObject {
  second_Item?: string;
  Address_Number?: string;
  Branch?: string;
  Requested_No: number;
  Typ_BOM?: string;
  UM?: string;
  Effective_From?: string;
  Line_No: number;
  Quantity?: number;
  Effective_Thru?: string;
  Cost_Center?: string;
  Ln_Ty?: string;
  Parent_Item_No?: string;
}

type Props = {
  request: itemObject;
  
};

const Item = ({request}: Props) => (
  < View>
    <View style={styles.requestContainer}>
    <View style={styles.request_detail}>
      <Text>Request Number</Text>
        <Text>Item Number </Text>
        <Text>Branch</Text>
        <Text>Type BOM</Text>
        <Text>UM</Text>
        <Text>From Date</Text>
        <Text>To Date</Text>
        <Text>Quantity</Text>
        <Text>Line Type</Text>
      </View>
      <View style={styles.request_detail}>
        <Text>{request.Requested_No}</Text>
        <View style={styles.request_header}>
          <Text style={styles.request_status}>{request.second_Item}</Text>
        </View>
        <Text>{request.Branch}</Text>
        <Text>{request.Typ_BOM}</Text>
        <Text>{request.UM}</Text>
        <Text>{request.Effective_From}</Text>
        <Text>{request.Effective_Thru}</Text>
        <Text>{request.Quantity}</Text>
        <Text>{request.Ln_Ty}</Text>
      </View>
    </View>
  </View>
);

const RequestDetailScreen = ({route,navigation}: RequestNavigationProp) => {

  const [data, setData] = useState<itemObject>(route.params!);
  const [data1, setData1] = useState([]);
  const [loading, setLoading] = useState(false);
  const [isFetching, setIsFetching] = useState(false);
  const [visible, setVisible] = useState(false);

  
  const handleApproved = async () => {
    const req = {
      Requested_No: data.Requested_No,
    };

    try {
      setLoading(true);
      let response = await APIKit.post(
        '/jderest/v3/orchestrator/BOM_Approval_button',
        req,
      );
      if (response.status === 200) {
        setLoading(false);
        Alert.alert('Status', 'Approved', [
          {text: 'OK', onPress: () => navigation.goBack()},
        ]);
      }
      setLoading(false);
    } catch (error) {
      console.log(error);
      setLoading(false);
    }
  };

  const handleRejected = async () => {
    const req = {
      Requested_No: data.Requested_No,
     // Reason: comment,
    };

    try {
      setLoading(true);
      let response = await APIKit.post(
        '/jderest/v3/orchestrator/BOM_Reject_button',
        req,
      );
      if (response.status === 200) {
        setLoading(false);
        Alert.alert('Status', 'Rejected', [
          {text: 'OK', onPress: () => navigation.goBack()},
        ]);
      }
    } catch (error) {
      console.log(error);
      setLoading(false);
    }
  };
  console.log(data)
  useEffect(() => {
    RequestList();

  }, [navigation]);

  const RequestList = async () => {
    try {
     // setIsFetching(true);
     let r = {
      "Requested_No": data.Requested_No 
    }
      let response = await APIKit.post(
        '/jderest/v3/orchestrator/BOM_Approve',
        r
      );

      const rowset = response.data.BOM_Approve_1.rowset;
      console.log(rowset)
      let sortedData = rowset.sort((a: itemObject, b: itemObject) =>
        a.Requested_No < b.Requested_No ? 1 : -1,
      );

      setIsFetching(false);
      setData1(sortedData);
    } catch (error) {
      console.log(error);
      setIsFetching(false);
    }
  };

  

  

  const renderItem = ({item}: {item: itemObject}) => {
    return <Item  request={item} />;
  };

  
  return (
    <View style={styles.container}>
      <View style={styles.container}>
        <FlatList
          data={data1}
          renderItem={renderItem}
          keyExtractor={item => item.Line_No.toString()}
          //onRefresh={() => onRefresh()}
         // refreshing={isFetching}
        />
        <View style={styles.btnContainer}>
        <TouchableOpacity style={styles.btn} onPress={handleApproved}>
          <Text style={styles.btnText}>Approve</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.btn}
          onPress={handleRejected}>
          <Text style={styles.btnText}>Reject</Text>
        </TouchableOpacity>
      </View>
      </View>
    </View>
  );
};

export default RequestDetailScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  btnContainer: {
    flexDirection: 'row',
    justifyContent: 'space-evenly',
    backgroundColor: '#fff',
  },
  btn: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-evenly',
    backgroundColor: '#1578bf',
    padding: 10,
    margin: 15,
    shadowOffset: {
      width: 0,
      height: 2,
    }},
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  btnText: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#fff',
  },
  centerText: {
    color: '#aaa9ad',
    fontWeight: 'bold',
    fontSize: 20,
  },
  reloadIcon: {
    padding: 10,
  },
  requestContainer: {
    backgroundColor: 'white',
    flexDirection: 'row',
    flex: 1,
    borderBottomWidth: 1,
    borderBottomColor: 'gray',
    paddingLeft: 10,
    paddingRight: 15,
    paddingTop: 15,
    paddingBottom: 15,
  },
  request_detail: {
    marginLeft: 10,
    flexDirection: 'column',
    flex: 1,
  },
  request_header: {
    alignItems: 'center',
    justifyContent: 'space-between',
    flexDirection: 'row',
    width: 300,
  },
  request_status: {
    fontWeight: 'bold',
  },
});

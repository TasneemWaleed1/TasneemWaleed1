import React from 'react';
import {StyleSheet, View, TouchableOpacity} from 'react-native';
import {Text, Icon} from '@rneui/themed';
import {HomeScreenNavigationProp} from '../../navigation/Home/HomeNavigator';

const HomeScreen = ({navigation}: HomeScreenNavigationProp) => {
  return (
    <View style={styles.mainContainer}>
      <View style={styles.container}>
        <TouchableOpacity
          style={styles.btnContainer}
          onPress={() => navigation.navigate('TransferNavigator')}>
          <Icon name="package" type="feather" color="#3B73AB" size={30} style={styles.btnIcon}/>
          <Text style={styles.btnText}>Transfer Request</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.btnContainer}
          onPress={() => navigation.navigate('DisposalNavigator')}>
          <Icon name="x-square" type="feather" color="#3B73AB" size={30} style={styles.btnIcon}/>
          <Text style={styles.btnText}>Disposal Request</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.btnContainer}
          onPress={() => navigation.navigate('BOMNavigator')}>
          <Icon name="x-square" type="feather" color="#3B73AB" size={30} style={styles.btnIcon}/>
          <Text style={styles.btnText}>BOM Request</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.btnContainer}
          onPress={() => navigation.navigate('RoutingNavigator')}>
          <Icon name="x-square" type="feather" color="#3B73AB" size={30} style={styles.btnIcon}/>
          <Text style={styles.btnText}>Routing Request</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.btnContainer}
          onPress={() => navigation.navigate('WorkOrderNavigator')}>
         <Icon name="x-square" type="feather" color="#3B73AB" size={30} style={styles.btnIcon}/>
          <Text style={styles.btnText}>Work Order Request</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default HomeScreen;

const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
    justifyContent: 'center',
  },
  container: {
    flex: 1,
  },
  btnIcon:{
  //  paddingTop: 20,
    height: 40,
  },
  btnContainer: {
    flex: 1,
   // padding: 10,
    backgroundColor: '#fff',
    height: 60,
    margin: 10,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,
    elevation: 4,
    borderRadius: 5,
    alignItems: 'center',
    justifyContent: 'center',
  },
  centerText: {
    color: '#aaa9ad',
    fontWeight: 'bold',
    fontSize: 30,
  },
  btnText: {
    paddingTop: 0,
    fontSize: 20,
    fontStyle: 'italic',
    fontWeight: 'bold',
    color: '#444452',
  },
});

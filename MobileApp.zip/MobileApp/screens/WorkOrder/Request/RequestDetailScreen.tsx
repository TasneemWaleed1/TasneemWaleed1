import React, {useState} from 'react';
import {
  StyleSheet,
  View,
  Alert,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import {Button, ListItem, Text, Overlay, Input} from '@rneui/base';
import {RequestNavigationProp} from '../../../navigation/WorkOrder/Request/RequestNavigator';
import APIKit from '../../../helpers/ApiKit';

interface itemObject {
  Item_Number?: string;
  Address_Number?: string;
  Branch?: string;
  Requested_No: number;
  Typ_Rtg?: string;
  Typ_BOM?: string;
  Co?: string;
  UM?: string;
  Order_Number?: number;
  Or_Ty?: string;
  Request_Date?: string;
  Status?: string;
  WO_Description?: string;
  WO_St?: string;
  Quantity_Ordered?: number;
  Description?: string;
}

const RequestDetailScreen = ({
  navigation,
  route,
}: RequestNavigationProp) => {
  const [data] = useState<itemObject>(route.params!);
  const [loading, setLoading] = useState(false);
  const [comment, setComment] = useState('');
  const [visible, setVisible] = useState(false);

  const handleApproved = async () => {
    const req = {
      Requested_No: data.Requested_No,
    };

    try {
      setLoading(true);
      let response = await APIKit.post(
        '/jderest/v3/orchestrator/WorkOrder_ApprovalButton',
        req,
      );
      if (response.status === 200) {
        setLoading(false);
        Alert.alert('Status', 'Approved', [
          {text: 'OK', onPress: () => navigation.goBack()},
          {text:`Order Number =${response.data.Order_Number}` }
        ]);
      }
      setLoading(false);
    } catch (error) {
      console.log(error);
      setLoading(false);
    }
  };

  const handleRejected = async () => {
    const req = {
      Requested_No: data.Requested_No,
      Reason: comment,
    };

    try {
      setLoading(true);
      let response = await APIKit.post(
        '/jderest/v3/orchestrator/WorkOrder_RejectButton',
        req,
      );
      if (response.status === 200) {
        setLoading(false);
        Alert.alert('Status', 'Rejected', [
          {text: 'OK', onPress: () => navigation.goBack()},
        ]);
      }
    } catch (error) {
      console.log(error);
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <View style={styles.loading}>
        <ActivityIndicator size="large" color="#00bfff" />
      </View>
    );
  }

  return (
    <ScrollView>
      <View>
        <ListItem bottomDivider>
          <ListItem.Content>
            <ListItem.Title right>Request Number</ListItem.Title>
          </ListItem.Content>
          <ListItem.Title>{data.Requested_No}</ListItem.Title>
        </ListItem>
        <ListItem bottomDivider>
          <ListItem.Content>
            <ListItem.Title right>Order Number</ListItem.Title>
          </ListItem.Content>
          <ListItem.Title>{data.Order_Number}</ListItem.Title>
        </ListItem>
        <ListItem bottomDivider>
          <ListItem.Content>
            <ListItem.Title right>Order Type</ListItem.Title>
          </ListItem.Content>
          <ListItem.Title>{data.Or_Ty}</ListItem.Title>
        </ListItem>
        <ListItem bottomDivider>
          <ListItem.Content>
            <ListItem.Title right>Item Number</ListItem.Title>
          </ListItem.Content>
          <ListItem.Title>{data.Item_Number}</ListItem.Title>
        </ListItem>
        <ListItem bottomDivider>
          <ListItem.Content>
            <ListItem.Title right>Branch</ListItem.Title>
          </ListItem.Content>
          <ListItem.Title>{data.Branch}</ListItem.Title>
        </ListItem>
        <ListItem bottomDivider>
          <ListItem.Content>
            <ListItem.Title right>Company</ListItem.Title>
          </ListItem.Content>
          <ListItem.Title>{data.Co}</ListItem.Title>
        </ListItem>
        <ListItem bottomDivider>
          <ListItem.Content>
            <ListItem.Title right>Type Routing</ListItem.Title>
          </ListItem.Content>
          <ListItem.Title>{data.Typ_Rtg}</ListItem.Title>
        </ListItem>
        <ListItem bottomDivider>
          <ListItem.Content>
            <ListItem.Title right>Type BOM</ListItem.Title>
          </ListItem.Content>
          <ListItem.Title>{data.Typ_BOM}</ListItem.Title>
        </ListItem>
        <ListItem bottomDivider>
          <ListItem.Content>
            <ListItem.Title right>Request Date</ListItem.Title>
          </ListItem.Content>
          <ListItem.Title>{data.Request_Date}</ListItem.Title>
        </ListItem>
        <ListItem bottomDivider>
          <ListItem.Content>
            <ListItem.Title right>UM</ListItem.Title>
          </ListItem.Content>
          <ListItem.Title>{data.UM}</ListItem.Title>
        </ListItem>
        <ListItem bottomDivider>
          <ListItem.Content>
            <ListItem.Title right>Quantity Ordered</ListItem.Title>
          </ListItem.Content>
          <ListItem.Title>{data.Quantity_Ordered}</ListItem.Title>
        </ListItem>
        <ListItem bottomDivider>
          <ListItem.Content>
            <ListItem.Title right>WO Desc</ListItem.Title>
          </ListItem.Content>
          <ListItem.Title>{data.WO_Description}</ListItem.Title>
        </ListItem>
      </View>
      <Overlay
        isVisible={visible}
        onBackdropPress={() => setVisible(!visible)}
        overlayStyle={styles.overlayContainer}>
        <View style={{}}>
          <Text style={styles.textPrimary}>Reason</Text>
          <Input
            placeholder="Comment"
            value={comment}
            onChangeText={value => setComment(value)}
          />
          <Button title="Confirm" onPress={handleRejected} />
        </View>
      </Overlay>
      <View style={styles.btnContainer}>
        <TouchableOpacity style={styles.btn} onPress={handleApproved}>
          <Text style={styles.btnText}>Approve</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.btn}
          onPress={() => {
            setVisible(!visible);
          }}>
          <Text style={styles.btnText}>Reject</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

export default RequestDetailScreen;

const styles = StyleSheet.create({
  btnContainer: {
    flexDirection: 'row',
    justifyContent: 'space-evenly',
    backgroundColor: '#fff',
  },
  btn: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-evenly',
    backgroundColor: '#1578bf',
    padding: 10,
    margin: 15,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,
    elevation: 4,
    borderRadius: 5,
    alignItems: 'center',
  },
  btnText: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#fff',
  },
  loading: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center',
  },
  overlayContainer: {
    width: '100%',
    height: '35%',
    justifyContent: 'center',
    backgroundColor: '#fff',
  },
  textPrimary: {
    textAlign: 'center',
    fontSize: 20,
  },
});
